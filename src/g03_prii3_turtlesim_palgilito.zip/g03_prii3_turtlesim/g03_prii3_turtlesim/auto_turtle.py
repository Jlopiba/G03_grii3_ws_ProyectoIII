import rclpy
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class AutoTurtle(Node):
    def __init__(self):
        super().__init__('auto_turtle')
        self.publisher_ = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self.timer = self.create_timer(0.1, self.move_pattern)
        self.step = 0
        self.get_logger().info('Nodo auto_turtle iniciado 🐢')

    def move_pattern(self):
        msg = Twist()

        # 1️⃣ Línea superior hacia la derecha
        if 0 <= self.step < 25:
            msg.linear.x = 1.0
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class AutoTurtle(Node):
    def __init__(self):
        super().__init__('auto_turtle')
        self.publisher_ = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self.timer = self.create_timer(0.1, self.move_pattern)
        self.step = 0
        self.get_logger().info('Nodo auto_turtle iniciado 🐢')

    def move_pattern(self):
        msg = Twist()

        # 1️⃣ Línea superior hacia la derecha
        if 0 <= self.step < 25:
            msg.linear.x = 1.0
            msg.angular.z = 0.0

        # 2️⃣ Giro hacia abajo (90º)
        elif 25 <= self.step < 35:
            msg.linear.x = 0.0
            msg.angular.z = -1.5

        # 3️⃣ Línea central hacia la izquierda
        elif 35 <= self.step < 60:
            msg.linear.x = 1.0
            msg.angular.z = 0.0

        # 4️⃣ Giro hacia abajo (90º)
        elif 60 <= self.step < 70:
            msg.linear.x = 0.0
            msg.angular.z = -1.5

        # 5️⃣ Línea inferior hacia la derecha
        elif 70 <= self.step < 95:
            msg.linear.x = 1.0
            msg.angular.z = 0.0

        # 6️⃣ Giro hacia arriba (180º)
        elif 95 <= self.step < 115:
            msg.linear.x = 0.0
            msg.angular.z = -1.5

        # 7️⃣ Línea de regreso (subiendo)
        elif 115 <= self.step < 140:
            msg.linear.x = 1.0
            msg.angular.z = 0.0

        # 8️⃣ Giro hacia la izquierda (para cerrar la parte superior)
        elif 140 <= self.step < 150:
            msg.linear.x = 0.0
            msg.angular.z = -1.5

        # 9️⃣ Línea final hacia la izquierda (parte superior del 3)
        elif 150 <= self.step < 175:
            msg.linear.x = 1.0
            msg.angular.z = 0.0

        # 🔟 Giro hacia abajo para cerrar la base del 3
        elif 175 <= self.step < 185:
            msg.linear.x = 0.0
            msg.angular.z = -1.5

        # 11️⃣ Línea final de cierre inferior (¡la que te faltaba!)
        elif 185 <= self.step < 205:
            msg.linear.x = 1.0
            msg.angular.z = 0.0

        # 🏁 Fin del movimiento
        else:
            msg.linear.x = 0.0
            msg.angular.z = 0.0

        self.publisher_.publish(msg)
        self.step += 1


def main(args=None):
    rclpy.init(args=args)
    node = AutoTurtle()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()


